package LabMid;

public class Student {

    String name;
    String registrationNo;
    String description;
    int semester;

    public Student(String name, String registrationNo, String description, int semester) {
        this.name = name;
        this.registrationNo = registrationNo;
        this.description = description;
        this.semester = semester;
    }
}
