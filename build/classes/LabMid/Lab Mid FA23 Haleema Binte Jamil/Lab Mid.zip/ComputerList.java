package LabMid;

interface ComputerList {

    ComputerIterator createIterator();
}
