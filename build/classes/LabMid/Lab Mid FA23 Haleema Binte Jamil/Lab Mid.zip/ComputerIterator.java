package LabMid;

interface ComputerIterator {

    boolean hasNext();

    Object next();
}
